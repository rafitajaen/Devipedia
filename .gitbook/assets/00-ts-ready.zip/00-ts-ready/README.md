# TS-Ready
It is an initial TypeScript installation. Ready for use.

## Installation
```
npm install
```

## Scripts

| Script          | Details |
| ------          | ------- |
|**npm start**    | Auto-Execution of index.ts (No transpilation && Hot Reload).| 
|**npm tsnode**   | Transpilation + Execution of index.ts | 
|**start:prod**   | Transpilation + Build + Execution |